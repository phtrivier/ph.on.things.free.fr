Plugins.manifest("water")
