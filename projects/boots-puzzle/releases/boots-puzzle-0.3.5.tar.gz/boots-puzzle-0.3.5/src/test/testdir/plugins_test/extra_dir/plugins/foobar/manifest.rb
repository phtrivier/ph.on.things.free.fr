Plugins.manifest!("foobar")
