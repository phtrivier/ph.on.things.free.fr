Plugins.manifest("static")
