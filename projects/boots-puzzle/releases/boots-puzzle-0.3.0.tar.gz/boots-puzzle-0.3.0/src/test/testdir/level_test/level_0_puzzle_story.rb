Story.for("level_0") do

end
