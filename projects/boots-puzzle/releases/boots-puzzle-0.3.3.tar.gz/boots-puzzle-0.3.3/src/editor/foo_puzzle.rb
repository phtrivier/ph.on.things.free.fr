class FooPuzzle < Puzzle
 dim 10,10
 rows do
  row "I---------"
  row "----------"
  row "----------"
  row "----------"
  row "----------"
  row "----O-----"
  row "----------"
  row "----------"
  row "----------"
  row "----------"
 end
end
