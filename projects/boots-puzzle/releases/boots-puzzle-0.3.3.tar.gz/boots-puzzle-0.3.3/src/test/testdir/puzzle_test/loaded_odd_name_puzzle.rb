class OddNamePuzzle < Puzzle
  dim 1,1
  rows do
    row "I"
  end
end
