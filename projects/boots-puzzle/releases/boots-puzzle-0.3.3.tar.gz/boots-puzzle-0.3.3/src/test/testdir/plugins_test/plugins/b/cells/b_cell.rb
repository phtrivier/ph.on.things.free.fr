class BCell < Cell
  def new_position
    [2,2]
  end
  def src
    "../img/b.png"
  end
end
