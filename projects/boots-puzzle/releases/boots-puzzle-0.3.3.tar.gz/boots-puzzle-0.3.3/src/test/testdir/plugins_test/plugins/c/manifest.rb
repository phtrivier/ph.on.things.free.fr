Plugins.manifest("c", ["b"])
