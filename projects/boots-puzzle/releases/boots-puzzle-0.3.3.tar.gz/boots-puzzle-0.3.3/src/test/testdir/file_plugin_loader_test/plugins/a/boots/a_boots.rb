class ABoots < Boots

  def new_position(puzzle, dir)
    [0,0]
  end

  def src
    "../img/toto.png"
  end

end
