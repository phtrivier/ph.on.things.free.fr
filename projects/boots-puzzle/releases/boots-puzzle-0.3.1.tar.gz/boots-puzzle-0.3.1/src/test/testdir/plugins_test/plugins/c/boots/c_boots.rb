class CBoots < Boots
  def new_position(pu, dir)
    [3,3]
  end
  def src
    "c/img/c_boots.png"
  end
end
