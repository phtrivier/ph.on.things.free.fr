class LoadedPuzzle < Puzzle
  dim 1,1
  rows do
    row "-"
  end
end
