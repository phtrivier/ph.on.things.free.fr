module StagedPuzzleStory
  Loaded = 15

  def init_story
  end

end
