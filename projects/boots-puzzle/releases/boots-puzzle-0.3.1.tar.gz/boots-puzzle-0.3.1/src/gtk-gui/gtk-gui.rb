# FIXTHIS

require 'gnomecanvas2'
require 'gconf2'

#
# Charactors
#

# class Storage < Gnome::CanvasRect
#   include Actor
#   def initialize(root, row, col)
#     super(root, :x1 => col * WIDTH, :y1 => row * HEIGHT,
#           :x2 => (col + 1) * WIDTH, :y2 => (row + 1) * HEIGHT,
#           :fill_color => "#99ffff",
#           :outline_color => "gray",
#           :width_pixels => 1.0)
#     lower_to_bottom
#   end
# end


# class Baggage < Gnome::CanvasGroup
#   include Actor
#   def initialize(root, map, row, col)
#     @map, @row, @col = map, row, col
#     super(root, :x => col * WIDTH, :y => row * HEIGHT)

#     Gnome::CanvasEllipse.new(self, :x1 => 1, :y1 => 2,
#                              :x2 => WIDTH - 2, :y2 => HEIGHT - 3,
#                              :outline_color => "black",
#                              :fill_color => "red",
#                              :width_units => 1.0)
#     Gnome::CanvasEllipse.new(self, :x1 => 5, :y1 => 5,
#                              :x2 => 9, :y2 => 9,
#                              :outline_color => "white",
#                              :fill_color => "white",
#                              :width_units => 1.0)
#     @pre_obj = Passage.new
#     @storage_area = false
#   end

#   def move_arround(dir_x, dir_y)
#     obj = @map[@row + dir_y][@col + dir_x]
#     if obj.kind_of? Passage or obj.kind_of? Storage
#       move(dir_x * WIDTH, dir_y * HEIGHT)
#       @map[@row][@col] = @pre_obj
#       @row, @col = @row + dir_y, @col + dir_x
#       @pre_obj = obj
#       @map[@row][@col] = self
#       raise_to_top
#       @storage_area = obj.kind_of?(Storage)
#       true
#     else
#       false
#     end
#   end

#   def storage_area?
#     @storage_area
#   end
# end

# class Wall < Gnome::CanvasGroup
#   include Actor
#   def initialize(root, row, col)
#     super(root, :x => col * WIDTH, :y => row * HEIGHT)

#     Gnome::CanvasRect.new(self, :x1 => 0, :y1 => 0,
#                           :x2 => WIDTH, :y2 => HEIGHT,
#                           :fill_color => "#55dd77",
#                           :outline_color => "black",
#                           :width_pixels => 1.0)
#    Gnome::CanvasLine.new(self, :points => [[0, 0], [0, HEIGHT]],
#                          :fill_color => "#eeffee",
#                          :width_pixels => 1.0)
#    Gnome::CanvasLine.new(self, :points => [[0, 0], [WIDTH, 0]],
#                          :fill_color => "#eeffee",
#                          :width_pixels => 1.0)
#   end
#   def move_arround(dir_x, dir_y)
#     false
#   end
# end

# class Worker < Gnome::CanvasGroup
#   include Actor
#   def initialize(root, map, row, col)
#     @map, @row, @col = map, row, col
#     @moves, @pushes = 0, 0
#     @undo = Array.new
#     super(root, :x => col * WIDTH, :y => row * HEIGHT)

#     Gnome::CanvasEllipse.new(self, :x1 => 1, :y1 => 1,
#                              :x2 => WIDTH - 1, :y2 => HEIGHT - 1,
#                              :outline_color => "black",
#                              :fill_color => "yellow",
#                              :width_units => 1.0)
#     Gnome::CanvasLine.new(self, :points => [[5, 4], [7, 7]],
#                             :fill_color => "black",
#                             :width_units => 2)
#     Gnome::CanvasLine.new(self, :points => [[WIDTH - 5, 4], [WIDTH - 7, 7]],
#                             :fill_color => "black",
#                             :width_units => 2)
#     Gnome::CanvasPolygon.new(self, :points => [[5, HEIGHT - 10],
#                                [WIDTH / 2, HEIGHT - 5], [WIDTH - 5, HEIGHT - 10]],
#                              :fill_color => "orange",
#                              :outline_color => "black")

#   end

#   def move_real(dir_x, dir_y)
#       move(dir_x * WIDTH, dir_y * HEIGHT)
#       @row, @col = @row + dir_y, @col + dir_x
#       raise_to_top
#   end

#   def move_arround(dir_x, dir_y)
#     obj = @map[@row + dir_y][@col + dir_x]
#     if obj.move_arround(dir_x, dir_y)
#       move_real(dir_x, dir_y)
#       @undo.push([obj, dir_x, dir_y])
#       @moves += 1
#       @pushes += 1 if obj.kind_of? Baggage
#     else
#       false
#     end
#   end
#   def undo
#     unmove = @undo.pop
#     if unmove
#       move_real(- unmove[1], - unmove[2])
#       unmove[0].move_arround( - unmove[1], - unmove[2])
#     end
#   end
#   attr_reader :moves, :pushes
# end

#
# Main Window
#

class MainWindow < Gtk::Window
  GCONF_PATH = "/apps/sokoban"
  KEYS = [
    [Gdk::Keyval::GDK_H, -1, 0], [Gdk::Keyval::GDK_L, 1, 0],
    [Gdk::Keyval::GDK_K, 0, -1], [Gdk::Keyval::GDK_J, 0, 1],
    [Gdk::Keyval::GDK_Left, -1, 0], [Gdk::Keyval::GDK_Right, 1, 0],
    [Gdk::Keyval::GDK_Up, 0, -1], [Gdk::Keyval::GDK_Down, 0, 1],
  ]

#   def create_stage(stage)
#     GC.start #If comment out here, error will be occured. Is it a Ruby-GNOME2 bug?

#     canvas = Gnome::Canvas.new(true)
#     canvas.freeze_notify

#     # CanvasGroup.new ?
#     root = Gnome::CanvasGroup.new(canvas.root, :x => 0, :y => 0)
#     width = 0
#     height = 0

#     canvas.set_size_request(800, 600)
#     # SCROLL REGION ?
#     canvas.set_scroll_region(0, 0, 800, 600)

#     background = Gnome::CanvasRect.new(canvas.root, :x1 => 0, :y1 => 0,
#                                        :x2 => width, :y2 => height,
#                                        :fill_color => "white",
#                                        :outline_color => "gray",
#                                        :width_pixels => 4.0)
#     background.lower_to_bottom
#     canvas.thaw_notify
#     if @canvas
#       @base_box.remove(@canvas)
#       @canvas.destroy
#     end

#     @canvas = canvas
#     @base_box.pack_end(@canvas, true, false, 0)
#     @canvas.show_all
#     update_label_stage
#     resize(width, size_request[1]) if size_request[1] > 0
#   end

  def update_label_stage
    @label_stage.set_text("[Level: #{@stage + 1}] #{@worker.moves} moves & #{@worker.pushes} pushes")
  end

  def quit
    Gtk.main_quit
  end

  def initialize(maps)
    super()

    # Actions
#     ag = Gtk::AccelGroup.new
#     KEYS.each do |key|
#       ag.connect(key[0], Gdk::Window::LOCK_MASK, Gtk::ACCEL_VISIBLE) {
#         move_arround(key[1], key[2])
#       }
#     end
#     ag.connect(Gdk::Keyval::GDK_R, 0, Gtk::ACCEL_VISIBLE) {
#       create_stage(@stage)
#     }
#     ag.connect(Gdk::Keyval::GDK_N, 0, Gtk::ACCEL_VISIBLE) {
#       stage = @stage + 1
#       stage = 0 if stage == @maps.size
#       create_stage(stage)
#     }
#     ag.connect(Gdk::Keyval::GDK_P, 0, Gtk::ACCEL_VISIBLE) {
#       stage = @stage - 1
#       stage = @maps.size - 1 if stage < 0
#       create_stage(stage)
#     }
#     ag.connect(Gdk::Keyval::GDK_U, 0, Gtk::ACCEL_VISIBLE) {
#       @worker.undo
#     }
#     ag.connect(Gdk::Keyval::GDK_Q, 0, Gtk::ACCEL_VISIBLE) {
#       quit
#     }
#     signal_connect("destroy") {
#       quit
#     }

    # Main Window
    set_border_width(0)
    vbox = Gtk::VBox.new
    @label_stage = Gtk::Label.new
    vbox.pack_start(@label_stage, false, true, 5)
    @base_box = Gtk::VBox.new(false, 0)
    @base_box.pack_start(vbox)
    color_box = Gtk::EventBox.new.add(@base_box)
    style = Gtk::Style.new.set_bg(Gtk::STATE_NORMAL, 65000, 65000, 50000)
    color_box.set_style(style)
    add(color_box)
    add_accel_group(ag)

    realize
    window.set_background(Gdk::Color.new(0, 0, 0))
  end

end


# CODE TO SHOW THE WINDOW ...
  Gtk.init
  MainWindow.new().show_all

  Gtk.main
