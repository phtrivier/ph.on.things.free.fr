class Level2Puzzle < Puzzle
  dim 3, 1
  rows do
    row "I-O"
  end
  named_cells do
    named_cell :middle, 0,1
  end
end
