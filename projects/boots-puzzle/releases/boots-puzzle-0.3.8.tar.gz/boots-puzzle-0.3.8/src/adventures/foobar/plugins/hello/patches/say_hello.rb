puts "PLUGIN LOADED : Hello, everyone !!"
