Cell.for_plugin("water", :parent => Wall) do
  swimable
  letter "~"
  img "water_cell.png"
end
