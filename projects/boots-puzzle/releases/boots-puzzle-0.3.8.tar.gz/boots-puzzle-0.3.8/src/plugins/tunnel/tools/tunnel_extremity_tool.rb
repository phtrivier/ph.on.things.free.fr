CellTool.for(TunnelExtremityCell)
