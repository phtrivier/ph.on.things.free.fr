Plugins.manifest("d")

