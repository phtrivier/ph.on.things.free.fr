class Level0Puzzle < Puzzle
  dim 2,2
  rows do
    row "I-"
    row "-O"
  end
end
