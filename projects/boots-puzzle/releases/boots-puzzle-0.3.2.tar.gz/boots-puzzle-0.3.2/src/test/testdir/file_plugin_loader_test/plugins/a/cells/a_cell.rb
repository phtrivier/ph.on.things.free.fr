class ACell < Cell
  letter "a"
  walkable
end
