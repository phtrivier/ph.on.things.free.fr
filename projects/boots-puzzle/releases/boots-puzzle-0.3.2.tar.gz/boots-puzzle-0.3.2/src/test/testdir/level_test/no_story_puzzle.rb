class NoStoryPuzzle < Puzzle
  dim 2,1
  rows do
    row "IO"
  end
end
