Plugins.manifest("events")
