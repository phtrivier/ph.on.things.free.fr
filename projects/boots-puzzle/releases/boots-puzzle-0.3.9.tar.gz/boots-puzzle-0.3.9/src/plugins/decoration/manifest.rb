Plugins.manifest("decoration")
