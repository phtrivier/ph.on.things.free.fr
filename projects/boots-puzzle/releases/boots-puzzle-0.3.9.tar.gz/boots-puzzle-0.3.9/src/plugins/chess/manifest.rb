Plugins.manifest("chess")
