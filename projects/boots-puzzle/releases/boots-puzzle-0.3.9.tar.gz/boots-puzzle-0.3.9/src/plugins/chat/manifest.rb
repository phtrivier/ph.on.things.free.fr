Plugins.manifest("chat", ["static"])
