class TunnelExtremityCell < Walkable
  letter ">"
  def src
    "tunnel/img/tunnel_extremity_cell.png"
  end
end
