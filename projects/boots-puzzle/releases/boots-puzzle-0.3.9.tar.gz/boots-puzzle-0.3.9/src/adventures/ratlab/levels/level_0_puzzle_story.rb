Story.for "level_0" do

  decorate_cell(:book1, :book1)
  decorate_cell(:book2, :book2)
  decorate_cell(:book3, :book1)
  decorate_cell(:scroll1, :scroll1)
  
end
