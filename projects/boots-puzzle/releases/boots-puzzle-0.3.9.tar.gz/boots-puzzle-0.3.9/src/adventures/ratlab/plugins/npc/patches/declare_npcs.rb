Chat.clear_chatters
Chat.chatter(:master, :name => "Master", :sprite => "npc/img/master.png")
