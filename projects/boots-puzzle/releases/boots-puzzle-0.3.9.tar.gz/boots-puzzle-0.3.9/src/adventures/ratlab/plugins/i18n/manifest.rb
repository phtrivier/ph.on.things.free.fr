Plugins.manifest("i18n", ["chat"])
