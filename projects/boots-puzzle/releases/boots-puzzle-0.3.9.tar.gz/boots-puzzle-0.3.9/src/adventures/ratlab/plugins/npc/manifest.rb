Plugins.manifest("npc", ["chat"])
