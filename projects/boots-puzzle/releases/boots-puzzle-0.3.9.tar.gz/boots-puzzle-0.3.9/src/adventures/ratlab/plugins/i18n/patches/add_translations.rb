# TODO : Use the language to 
# translate things differently in French.
class Puzzle
  Translations = {
    # LEVEL 1
    "level1.hi" => "Hi. You must be the new apprentice !.\nWould you be as nice as to try and go through this doorish thing rigth here ?",
    "level1.justdoit" => "It's for science. Just do it.",
    "level1.eureka" => "This works !!! My spatio-spatial automatic transportation works !!! And you're still alive !",
    "level1.okthisworks" => "Ok, this is not a toy.",
    "level1.getout" => "Fine, meet me in the next room, we have to talk.",

    # LEVEL 2
    "level2.insane" => "You seem to be a pretty reasonnably insane person. So you see those two big switchy stuff over there ? One of them opens a passage to the exit door. The other one ...",
    "level2.insane2" => "... well, you're not allergic to high voltage cur... I mean, you've never be struck by lightning and hurt a lot, have you ? ",
    "level2.no_lightning" => "Wait ? What ? No lightning and screaming and burnt flesh ? I'm getting better at this ! Ahem, I mean, the other one it is, then",
    "level2.open" => "Great, you've open the door. Meet me in next room..."
  

  }

end
  
