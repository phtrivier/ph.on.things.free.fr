Story.for("level_2_puzzle") do
    story_event :middle, Walkable do |puzzle|
      puzzle.message "Hello everyone !!"
    end
end

