Chat.clear_chatters
Chat.chatter(:bob, :name => "Bob", :sprite => "npc/img/bob.png")
Chat.chatter(:alice, :name => "Alice", :sprite => "npc/img/alice.png")
