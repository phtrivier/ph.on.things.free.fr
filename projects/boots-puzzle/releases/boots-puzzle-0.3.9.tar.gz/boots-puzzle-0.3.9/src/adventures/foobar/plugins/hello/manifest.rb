Plugins.manifest("hello")
