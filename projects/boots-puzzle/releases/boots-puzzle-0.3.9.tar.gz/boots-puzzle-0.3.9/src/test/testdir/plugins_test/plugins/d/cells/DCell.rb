class DCell < Cell
  def src
    nil
  end
end
