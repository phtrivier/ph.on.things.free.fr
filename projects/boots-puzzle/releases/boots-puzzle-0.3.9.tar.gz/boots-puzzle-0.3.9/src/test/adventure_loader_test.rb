require 'bp_test_case'

class AdventureLoaderTest < BPTestCase

  def test_adventure_loader_uses_file_loader
  end

end
