Plugins.manifest("switch", ["static"])

