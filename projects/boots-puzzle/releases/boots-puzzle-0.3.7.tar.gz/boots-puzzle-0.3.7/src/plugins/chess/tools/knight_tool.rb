BootsTool.for(KnightLeftBoots)
BootsTool.for(KnightRightBoots)

