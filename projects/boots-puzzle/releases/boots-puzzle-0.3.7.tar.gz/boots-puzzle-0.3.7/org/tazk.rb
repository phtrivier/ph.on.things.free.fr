# TODO : 

#------------
# tazk new 

# Creates a template for a tazk, a file for it, and display the name of the file
# (Note : the bug number is known either by brute-forcefully counting, or by keeping a hiden .tazk.yml file with the latest bug number (usefull if file disappear from a repository to another)

# Bugs is assigned to noone (it goes straight to the 'open' folder)

#-----------------
# tazk assign pht 

# Moves the bug to the open/pht folder (creating it if necessary -- really just a shortcut)

#----------------
# tazk close 12

# Closes the bug and moves it to the closed folder (really just a shortcut)

#----------------
# tazk see pht

# Shows the title of all the bugs of the user pht, with a status. Status is user defined, it is just openned by default, but you can type whatever you want.

# What we WONT do : 
# * Search : those are text files, use grep and find
# * UI to display / edit : this is what emacs / vi is done. Use org-mode.
# * Complicated workflow : who cares ? either there is something to do, or there is not. 
# Discussing things is part of the task. 
# * Communication : Just put your question in the bug, assign it, git commit it / compress-send the folder / do whatever you want. And just tell people to read there bloody tazk list.
 
# What we dont do YET : 
# * attachement (will need a folder next to the bugs ('docs'), with one subfolder per tazk
# * discovery of 'new' tasks (just to know if something changed since last time you checked the repository)
# * conflict resolution : it is doable by hand, but then maybe we can help. In particular timestamping whenever something occurs could help. 
 
