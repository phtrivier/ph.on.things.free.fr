require 'sdl'
require 'scene'
require 'score_computer'
require "sprite"
require "title_screen_mode"

class Gui

  GAME_PERIOD = 30.0

  def initialize(w,h, off_x, off_y_top, off_y_bottom)
    SDL.init( SDL::INIT_VIDEO )
    @w,@h = w,h
    @screen = SDL::setVideoMode(w,h,24,SDL::SWSURFACE)
    @white = @screen.mapRGB 255,255,255
    @black = @screen.mapRGB 0,0,0
    @blue = @screen.mapRGB 0,0,255
    @yellow = @screen.mapRGB 255, 255, 0
    @red = @screen.mapRGB 255, 0, 0
    @cyan = @screen.mapRGB 0,255, 255
    @orange = @screen.mapRGB 255, 128, 0
    @pink = @screen.mapRGB 255, 184, 222
    @pill_color = @screen.mapRGB 255, 184, 151

    @events = []
    @draw_times = []
    @arrow_down = { }

    @window_offset_x = off_x
    @window_offset_y = off_y_top

    SDL::TTF.init
    @font = SDL::TTF.open(resource("fonts/VeraBd.ttf"),14)
    @font.style = SDL::TTF::STYLE_NORMAL
    @font

    # TODO : make this "out" of the gui ?
    build_scene!

    # Build the sprites for everyone
    build_sprites!

  end

  def build_sprites!
    build_pacman_sprite
    build_ghosts_sprites
  end

  def build_ghosts_sprites

    @ghost_sprites = { }
    GhostFactory::GHOST_COLORS.each do |color|
      sprite = Sprite.new(20,20)
      frames = [10]
      sprite.animations=[:left, :down, :up, :right, :steady, :respawning, :afraid]
      f = { }
      sprite.animations.each do |a|
        f[a] = frames
      end
      f[:afraid] = [2500,3000,4000,5000]
      sprite.frames = f
      sprite.sprite_sheet = SDL::Surface.load("src/gui/ghost_#{color}.png")
      sprite.animation = :steady
      @ghost_sprites[color] = sprite
    end

  end

  def build_pacman_sprite

    # TODO : Get the dimension in a nicer way ?
    p = Pac.new
    @pacman_sprite = Sprite.new(20, 20)
    frames = [300,500,600,800]
    @pacman_sprite.animations = [:right, :up, :down, :left, :steady]
    @pacman_sprite.frames = {
      :right => frames,
      :left => frames,
      :up => frames,
      :down => frames,
      :steady => frames
    }
    @pacman_sprite.sprite_sheet = SDL::Surface.load("src/gui/pacman.png")
    @pacman_sprite.animation = :steady

  end

  def draw_title_screen

    if (!@title_screen)
      @title_screen = SDL::Surface.load("src/gui/title_screen.png")
    end

#    @screen.blit(@title_screen, 0, 0)

    SDL.blitSurface(@title_screen,0,0,
                    0,0,
                    @screen, 0, 0)

  end

  # Draw a line of text
  # line : the text to be drawn
  # x,y : coordinates
  # color : the color of the text
  def draw_text_line(line, x, y, color)
    r,g,b = @screen.get_rgb(color)
    @font.draw_solid_utf8(@screen, line, x, y, r, g, b)
  end

  def resource(file_name)
    "./src/gui/#{file_name}"
  end

  def setup_default_maze
    @scene.setup!(resource("default.maze"))
  end

  def build_scene!
    @scene = Scene.new
    @scene.game_mode = TitleScreenMode.new(@scene)
  end

  def main_loop
    @running = true
    @last_time = SDL.get_ticks
    @scene.start!(@last_time)

    while @running

       while event = SDL::Event2.poll
         @events << event
         case event
         when SDL::Event2::Quit
           exit
         when SDL::Event2::KeyDown
           handle_input_down!(event.sym)
         end
       end

      current_time = SDL.get_ticks
      dt = current_time - @last_time
      if  dt > GAME_PERIOD
        @last_time = current_time
        # TODO : Actually some things might be simpler if I only used dt here ...
        @scene.update!(current_time)
        # TODO : Should I always forward this ?
        # Aren't there cases where it is useless ?
        @pacman_sprite.forward!(dt)

        # TODO : Implement afraid, and
        # advance ghosts sprites as required...
        GhostFactory::GHOST_COLORS.each do |color|
          @ghost_sprites[color].forward!(dt)
        end

      end
      @draw_times << current_time
      draw_all!
      @screen.update_rect(0,0,0,0)

    end

  end

  def show_events
    @events.each do |e|
      puts("Handled event #{e}")
    end
  end

  def show_drawing_times
    @draw_times.each do |d|
      puts("Drawn at #{d}")
    end
  end

  def is_arrow?(sym)

    [SDL::Key::DOWN,
         SDL::Key::UP,
         SDL::Key::LEFT,
         SDL::Key::RIGHT].member?(sym)

  end

  def to_dir_symbol(key)
    case key
      when SDL::Key::UP then :up
      when SDL::Key::DOWN then :down
      when SDL::Key::LEFT then :left
      when SDL::Key::RIGHT then :right
    end
  end

  # TODO : Actually, that's the mode themselves which should handle
  # the inputs, rather than letting it be done by
  # the GUI.
  # This results in this stupid switch on (@scene.game_mode.name ==)
  def handle_input_down!(sym)

    if (@scene.game_mode.name == :title)
      @scene.game_mode = InGameMode.new(@scene)
      setup_default_maze
      @scene.start!(SDL.get_ticks)
    else
      if (is_arrow?(sym))
        @scene.pac.steer(to_dir_symbol(sym))
      elsif sym == SDL::Key::P
        toggle_pause
      end
    end

  end

  def draw_state_line(txt)
    draw_text_line(txt, 160,10, @white)
  end

  def draw_all!
    # Clear the screen
    @screen.fill_rect(0,0,@w,@h, @black)
    @scene.game_mode.draw(self)
  end

  def draw_cells
    w = @scene.maze.cell_w
    @scene.maze.each_cells do |c,i,j|
      if (!c.walkable?)
        if (c.visible?)
          draw_wall(i,j,w)
        end
      elsif (c.is_pill?)
        draw_pill(i,j,w)
      elsif (c.is_super_pill?)
        draw_super_pill(i,j,w)
      end
    end
  end

  def in_window(i,j,w, offset_x = 0, offset_y = 0)
    [j*w + offset_x + @window_offset_x, i*w + offset_y + @window_offset_y]
  end

  def draw_pill(i,j,w)
    x,y = in_window(i,j,w,w/2, w/2)
    @screen.draw_filled_circle(x,y, w/10, @pill_color )
  end

  def draw_super_pill(i,j,w)
    x,y = in_window(i,j,w, w/2, w/2)
    @screen.draw_filled_circle(x,y, w/5, @pill_color)
  end

  def draw_wall(i,j,w)
    x,y = in_window(i,j,w)
    @screen.draw_rect(x,y,w,w, @blue)
  end

  def with_window_offset(x,y)
    [x + @window_offset_x, y + @window_offset_y]
  end

  def to_animation(vel)
    case vel
    when [0,0] then :steady
    when [-1,0] then :left
    when [+1,0] then :right
    when [0,+1] then :down
    when [0,-1] then :up
    end
  end

  def draw_pacman
    p = @scene.pac

    @pacman_sprite.animation = to_animation(p.vel)

    x,y = p.pos
    x1,y1 = with_window_offset(x,y)
    w = p.w
    draw_pacman_at(x1,y1,w)
  end

  def draw_sprite_at(sprite, x, y , w)
    # TODO : Set the animation in frame depending on the
    # direction of the pac
    surface, sprite_x,sprite_y,sprite_w,sprite_h = sprite.current_frame

    # x,y is the center
    # pac is assumed to be in a square box
    x,y = x - w/2, y - w/2

#    SDL::Surface.blit ?
    SDL.blitSurface(surface,sprite_x,sprite_y,
                    sprite_w,sprite_h,
                    @screen, x, y)
  end

  def draw_pacman_at(x,y,w)

    draw_sprite_at(@pacman_sprite, x,y,w)

#    @screen.draw_filled_circle(x,y,w*0.6, @yellow)
  end

  def draw_ghosts
    @scene.ghosts.each do |g|
      draw_ghost(g)
    end
  end

  # TODO : Define the colors with the right values for each ghost
  def to_gui_color(color)
    case color
    when :red then @red
    when :cyan then @cyan
    when :pink then @pink
    when :orange then @orange
    else raise RuntimeError.new("<Invalid color symbol to translate : #{color}>")
    end
  end

  def toggle_afraid
    @scene.toggle_afraid!
  end

  # Not so happy about this one ...
  def toggle_pause

    if (@scene.game_mode.name == :pause)
      @scene.game_mode = @scene.game_mode.previous_mode
    else
      @scene.game_mode = PauseMode.new(@scene.game_mode)
    end

  end

  def draw_ghost(g)
    x,y = g.pos
    x1,y1 = with_window_offset(x,y)
    w = g.w
    color = @blue

    sprite = @ghost_sprites[g.color]

    if (g.respawning?)
      sprite.animation = :respawning
    elsif (g.afraid?)
      sprite.animation = :afraid
    else
      sprite.animation = to_animation(g.vel)
    end

    draw_sprite_at(sprite, x1,y1,w)

#     if (g.respawning?)
#       color = @white
#     elsif (!g.afraid)
#       color = to_gui_color(g.color)
#     end
#     @screen.draw_filled_circle(x1,y1,w*0.6, color)

#    draw_ghost_path(g)

  end

  def draw_ghost_path(g)
    # Just to be sure, show the goal of the ghost
    if (g.goal)
      #      i,j = g.goal
      w = @scene.maze.cell_w
      g.plan.each do |p|
        i,j = p
        x,y = in_window(i,j,w)
        @screen.draw_rect(x,y,w,w, to_gui_color(g.color))
      end
    end
  end

  def draw_score
    draw_text_line("Score : #{@scene.score}", 160,10, @white)
  end

  def draw_lives
    x = 30
    p = @scene.pac
    @scene.remaining_lives.times do
      draw_pacman_at(x, 485, p.w)
      x = x + p.w * 2
    end
  end

  def draw_get_ready
    draw_text_line("GET READY !!",150,290, @white)
  end

  def draw_game_over
    draw_text_line("GAME OVER", 150, 200, @white)

    draw_text_line("Your score : #{@scene.score}", 140, 300, @white)

  end

end

def play

  default_maze_row_count = 22
  default_maze_col_count = 20
  default_w = 20

  off_x = 2
  off_y_top = 30
  off_y_bot = 30

  w = default_maze_col_count * default_w + off_x * 2
  h = default_maze_row_count * default_w + off_y_top + off_y_bot

  g = Gui.new(w, h, off_x, off_y_top, off_y_bot)
  g.main_loop
end
