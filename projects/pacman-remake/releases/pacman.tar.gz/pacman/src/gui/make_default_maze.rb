out = File.open("default.maze", "w")
File.open("default.maze.half").each do |line|
  half_line = line.gsub(" ", ".")[0..-3]
  full_line = half_line + half_line.reverse + "\n"
  fix_entry = full_line.gsub("II", ".I")
  out << fix_entry
end
