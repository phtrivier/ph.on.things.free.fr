require "chaser_life_cycle"
require "ambusher_life_cycle"
require "fickle_life_cycle"
require "stupid_life_cycle"
require "afraid_life_cycle"

class GhostFactory

  GHOST_COLORS = [:red, :pink,:cyan, :orange]
  VELOCITIES = [100.0, 90.0, 70.0, 70.0]
  LIFE_CYCLE_CLASSES = [ChaserLifeCycle, AmbusherLifeCycle, FickleLifeCycle, StupidLifeCycle]

  def ghost_color(index)
    GHOST_COLORS[index]
  end

  def make_velocity(index)
    VELOCITIES[index]
  end

  def make_life_cycle(scene, ghost, index)
    LIFE_CYCLE_CLASSES[index].new(scene, ghost)
  end

  # TODO : Give different life cycles to each ghosts
  def make_ghost(scene, ghost_index, x, y)
    g = Ghost.new(scene.maze, x, y, ghost_color(ghost_index))
    g.regular_life_cycle = make_life_cycle(scene, g, ghost_index)
    g.afraid_life_cycle = AfraidLifeCycle.new(scene, g)
    g.regular_velocity = make_velocity(ghost_index)
    g.set_afraid(false)
    g
  end

end
