require "cell"
require "cell_factory"
require 'pac'

# A maze in which the pacman moves.
# The maze is organised by cells, altougth
# the pac is positionned pixel by pixel.
class Maze

  DEFAULT_CELL_W = 20.0

  attr_accessor :cell_w, :pac

  def initialize()
    @cells = []
    @cell_w = DEFAULT_CELL_W
    @pac = nil
    @pill_eaten_handlers = []
    @maze_height = @maze_width = 0
    @str = nil
  end

  # Load a string representing a maze
  def load!(str)
    @f = CellFactory.new
    @str = str
    reload!()
  end

  def reload!
    @cells = []
    @str.strip.each_line do |line|
      row = @f.parse_line(line)
      @cells << row
    end

    if (@cells.size > 0)
      @maze_height = @cells.size * @cell_w + @cell_w
      @maze_width = @cells[0].size * @cell_w + @cell_w
    end
  end

  # Get a cell by position
  def cell(i,j)
    if (@cells[i] == nil)
      nil
    else
      @cells[i][j]
    end
  end

  # Where is the entry of the maze ?
  # Return an array i,j (a cell position)
  def entry
    res = nil
    @cells.each_with_index do |row, i|
      row.each_with_index do |c,j|
        if (c.entry?)
          res = [i,j]
          break
        end
      end
    end
    res
  end

  # How many pills (small) are there still to eat ?
  # TODO(pht) : Probably sub-optimal
  def pills_count
    @cells.inject(0) do |total, row|
      row.inject(total) do |sub_total,c|
        sub_total + c.pills_count
      end
    end
  end

  # How many super pills are there still to eat ?
  # TODO(pht) : Probably sub-optimal
  def super_pills_count
    @cells.inject(0) do |total, row|
      row.inject(total) do |sub_total,c|
        sub_total + c.super_pills_count
      end
    end
  end

  # Is the mazed cleared (nothing more to eat) ?
  def cleared?
    (super_pills_count == 0 && pills_count == 0)
  end

  # In which cell is a point (x,y) located ?
  # The cell itself is returned.
  def cell_at_point(x,y)
    i,j = cell_coord_at_point(x,y)
    cell(i,j)
  end

  # Coordinate of the cell at point (x,y).
  # Only coordinates are returned.
  def cell_coord_at_point(x,y)
    i = y / cell_w
    j = x / cell_w
    [i.floor,j.floor]
  end

  # Eat the pills on a cell
  def eat!(i,j)
    c = cell(i,j)
    if (c != nil)
      eat_cell!(c, i, j)
    end
  end

  # Eat the pills on cell at point (x,y)
  def eat_at_point!(x,y)
    c = cell_at_point(x,y)
    if (c != nil)
      i,j = cell_coord_at_point(x,y)
      eat_cell!(c,i,j)
    end
  end

  # Can you move a box to a given position
  # without hitting a wall ?
  def can_walk?(box, x, y)

    if (!valid_point?(x,y))
      false
    else
      # Look for a corner that hits
      # an unwalkable cell
      hitting_corner = box.corners(x,y).find do |corner|
        x,y = corner
        c = cell_at_point(x,y)
        (c != nil) and (!c.walkable?)
      end
      (hitting_corner == nil)
    end
  end

  def valid_point?(x,y)
    x > 0 and y > 0 and (y < @maze_height) and (x < @maze_width)
#    y > 0 and (y < @maze_height)
  end

  # Iterate over each cells
  def each_cells
    @cells.each_with_index do |line,i|
      line.each_with_index do |cell,j|
        yield cell,i,j
      end
    end
  end

  def clear_pill_eaten_handlers
    @pill_eaten_handlers = []
  end

  def add_pill_eaten_handler(handler)
    @pill_eaten_handlers << handler
  end

  # Eat a cell and propagate event
  # c should be a non null cell
  # i,j should be coordinates of a cell
  def eat_cell!(c, i, j)
    res = c.eat!
    if (res != Cell::NOTHING_EATEN)
      super_pill = (res == Cell::SUPER_PILL_EATEN)
      @pill_eaten_handlers.each do |handler|
        handler.call(i,j,super_pill)
      end
    end
  end

  def cell_center(i,j)
    [j*@cell_w + @cell_w/2, i*@cell_w + @cell_w/2]
  end

  def squared_dist(x1,y1, x2, y2)
    dx = (x1 - x2).abs
    dy = (y1 - y2).abs
    dx*dx + dy*dy
  end

  # Is a box centered on a given cell of the maze?
  # b : the box
  # i,j : a cell's position
  # p : the accepted precision between the center
  # of the box and the center of the cell
  def is_centered_on?(b, i, j , p=10)
    center_x, center_y = cell_center(i,j)
    x,y = b.pos
    sd = squared_dist(center_x, center_y, x, y)
    sd < p*p
  end

  # The position of a mobile after a small amount of time.
  # Note that the position is artificially "centered" to make
  # the move sleeker.
  # For example, if you move to the top, you x position is always one
  # of the center of a cell.
  def new_position(mobile, dt)
    x,y = mobile.pos
    vx, vy = mobile.vel
    w = cell_w

    # "Normal' new positions
    v = mobile.velocity
    new_x = x + (vx * v * (dt/ 1000.0))
    # Handles tunnels properly
    new_x = new_x % (w*@cells[0].size)
    new_y = y + (vy * v * (dt/ 1000.0))

    # Centered
    centered_x = ((new_x / w).floor)*w + w/2
    centered_y = ((new_y / w).floor)*w + w/2

    if (vx != 0)
      [new_x, centered_y]
    else
      [centered_x, new_y]
    end
  end

  def try_move_mobile!(m, dt, &block)
    new_x, new_y = new_position(m, dt)
    if can_walk?(m, new_x, new_y)
      m.set_pos(new_x, new_y)
      if (block_given?)
        block.call(new_x, new_y)
      end
    end
  end

  def try_move_pac!(pac, dt)
    try_move_mobile!(pac, dt) do |new_x, new_y|
      eat_at_point!(new_x,new_y)
    end
  end

  def try_move_ghost!(g, dt)
    g.act!(self)
    try_move_mobile!(g, dt)
  end

  def ghost_entries
    res = []
    each_cells do |c,i,j|
      if (c.ghost_entry?)
        res << [i,j]
      end
    end
    res
  end

  def dims
    [@cells.size, @cells[0].size]
  end

  def valid_cell_position?(i,j)
    i > 0 and j > 0 and i < @cells.size and j < @cells[i].size
  end

  def walkable_neighbours(pos)
    i,j = pos
    succs = [[i+1,j], [i,j+1], [i-1,j], [i, j-1]]
    succs.delete_if do |s|
      i0,j0 = s
      !valid_cell_position?(i0,j0) || !cell(i0,j0).walkable?
    end
  end

end
