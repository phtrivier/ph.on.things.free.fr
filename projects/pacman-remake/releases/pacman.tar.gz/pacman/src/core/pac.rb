require 'mobile'

class Pac < Mobile

  SIZE = 15.0
  DEFAULT_VELOCITY = 100.0

  def initialize
    super(0,0,SIZE, SIZE, 0.0, 0.0, DEFAULT_VELOCITY)
  end

end
