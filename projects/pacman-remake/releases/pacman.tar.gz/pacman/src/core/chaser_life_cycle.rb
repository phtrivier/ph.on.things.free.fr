require "life_cycle"
require "chaser_strategy"
require "astar_planner"

class ChaserLifeCycle < LifeCycle

  DEFAULT_PERIOD = 1000

  def initialize(scene, ghost, period = DEFAULT_PERIOD)
    super(scene)
    @strategy = ChasePacmanStrategy.new
    @planner = AStarPlanner.new(scene)
    @ghost = ghost
    @period = period
  end

end
