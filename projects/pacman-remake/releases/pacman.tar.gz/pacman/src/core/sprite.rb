require "box"

class Sprite < Box

  attr_accessor :sprite_sheet, :frames, :animation, :animations

  def initialize(w,h)
    super(0,0,w,h)
    @clock = 0
    @frames = []
  end

  def current_frame
    frame_index = frame_index_at(@clock, @frames[@animation])
    animation_index = @animations.index(@animation)
    @x = frame_index * @w
    @y = animation_index * @h
    [@sprite_sheet, @x,@y,@w,@h]
  end

  def forward!(dt)
    last_frame_timing = @frames[@animation][-1]
    @clock = (@clock + dt) % last_frame_timing
  end

  def frame_index_at(clock, list)
    frame_index = 0
    pairs(list) do |early, later|
      if (early <= clock) and (clock < later)
        break
      else
        frame_index = frame_index + 1
      end
    end
    frame_index
  end

  # Split up a list of frame timings
  # The list [10, 20, 30] is
  # split into [ [0,10], [10, 20], [20, 30]]
  def pairs(l)
    l.each_with_index do |element, index|
      if (index == 0)
        yield [0, element]
      else
        yield [l[index-1], element]
      end
    end
  end

end
