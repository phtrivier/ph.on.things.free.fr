require "life_cycle"
require "astar_planner"

class FickleStrategy

  KNOWN_GOALS = [ [11,6], [11,13],
                  [8,4], [8,15],
                  [13, 4], [13,15]]

  def initialize
    @index = 0
  end

  def find_goal(scene, ghost)
    old_index = @index
    while (@index == old_index)
      @index = rand(KNOWN_GOALS.size)
    end
    KNOWN_GOALS[@index]
  end

end

class FickleLifeCycle < ChaserLifeCycle

  def initialize(scene, ghost, period = 3000)
    super(scene, ghost, period)
    @strategy = FickleStrategy.new
    @planner = AStarPlanner.new(scene)
  end

end

