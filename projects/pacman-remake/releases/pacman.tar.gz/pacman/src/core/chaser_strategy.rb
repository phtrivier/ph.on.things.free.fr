class ChasePacmanStrategy

  def find_goal(scene, ghost)
    x,y = scene.pac.pos
    scene.maze.cell_coord_at_point(x,y)
  end

end
