require "mobile"
require 'life_cycle'
require "respawn_life_cycle"

class Ghost < Mobile

  DEFAULT_SIZE = 15.0
  DEFAULT_VELOCITY = 80.0
  RESPAWN_VELOCITY = 100.0

  attr_accessor :plan, :life_cycle, :color
  attr_accessor :regular_velocity, :regular_life_cycle
  attr_accessor :afraid_life_cycle
  attr_reader :goal, :afraid

  def initialize(maze, x=0, y=0, color=:red)
    super(x,y, DEFAULT_SIZE, DEFAULT_SIZE, 0.0, 0.0, DEFAULT_VELOCITY)
    @maze = maze
    @plan = []
    @color = color
    @respawning = false
    @regular_velocity = Ghost::DEFAULT_VELOCITY
  end

  # Set the goal
  # g : i,j of the cell that is the goal of
  # the ghost
  def goal=(g)
    @goal=g
  end

  def on_goal?
    i,j = @goal
    @maze.is_centered_on?(self, i,j)
  end

  # Try and consume a part of the plan
  # This assumes that the plan is properly
  # made of contiguous cells.
  def act!(maze)
    if (!@plan.empty?)
      n = @plan[0]
      i,j = n
      if (maze.is_centered_on?(self, i,j))
        @plan.delete_at(0)
      else
        steer_to_reach!(n, maze)
      end
    end
  end

  def steer_to_reach!(cell, maze)
    ghost_i, ghost_j = maze.cell_coord_at_point(@x,@y)
    dest_i, dest_j = cell

    dir = nil
    if (ghost_i == dest_i)
      if (ghost_j < dest_j)
        dir = :right
      else
        dir = :left
      end
    elsif (ghost_i < dest_i )
      dir = :down
    else
      dir = :up
    end
    steer(dir)
#    puts "Ghost Stering to reach #{cell}"
#    puts "Ghost will go #{dir}"
  end

  def start!(time)
    @life_cycle.start!(time)
  end

  # Updates the ghost plan, or movement, based on its position
  def update!(scene, dt)
    @life_cycle.update!(scene, dt)
  end

  def afraid?
    @afraid
  end

  def set_afraid(afraid)
    @afraid = afraid
    # Respawning ghosts should be handled differently
    if (!respawning?)
      if (@afraid)
        # Store old values
        @regular_life_cycle = @life_cycle
        @regular_velocity = @velocity
        # Use new ones
        @life_cycle = @afraid_life_cycle
        @afraid_life_cycle.start!(0)
        # Ghosts should be slower when they are afraid, actually !
        @velocity = 30.0
      else
        # Go back to old values
        @life_cycle = @regular_life_cycle
        @velocity = @regular_velocity
      end
    end
  end

  def kill!
#    puts ("Killing the ghost #{self}")
    @respawning = true
    @life_cycle = RespawnLifeCycle.new(self, @life_cycle)
    @life_cycle.start!(0)
    @velocity = RESPAWN_VELOCITY
  end

  # Is the ghost currently going back to
  # the center of the maze to respawn ?
  def respawning?
    @respawning
  end

  # Resurect a ghost.
  # This assumes that the ghost is respawning
  def respawn!
#    puts "Respawning the ghost #{self}"
    if (!respawning?)
      raise RuntimeError.new("Attempt to resurect #{self} while not respawning!")
    end
    @respawning = false
    @velocity = @regular_velocity
    @life_cycle = @regular_life_cycle
  end

end
