require "searcher"

class MazeSuccessorBuilder

  def initialize(maze)
    @maze = maze
  end

  def successors(node, goal)
    succs = @maze.walkable_neighbours(node.position)
    succs.collect do |succ|
      i,j = succ
      c = 1
      h = estimated_cost_to_goal(succ, goal)
      [i,j,c,h]
    end

  end

  def estimated_cost_to_goal(node, goal)
    i,j = goal
    i0,j0 = node
    di = i0 - i
    dj = j0 - j
    # Euclidian distance : might be a bit long to compute ?
#    sq_dist = di*di + dj*dj
#    Math.sqrt(sq_dist).floor
    # Manhattan distance
    di.abs + dj.abs
  end

end
