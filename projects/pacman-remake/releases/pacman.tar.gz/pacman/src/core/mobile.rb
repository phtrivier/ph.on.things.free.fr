require "box"

class Mobile < Box

  attr_reader :vx, :vy
  attr_accessor :velocity

  def initialize(x,y,w,h,vx,vy, v)
    super(x,y,w,w)
    @vx = vx
    @vy = vy
    @velocity = v
  end

  def vel
    [@vx, @vy]
  end

  def set_vel(vx, vy)
    @vx = vx
    @vy = vy
  end

  def steer(dir)
    case dir
    when :up then @vx,@vy = 0, -1
    when :down then @vx, @vy = 0, +1
    when :left then @vx, @vy = -1,0
    when :right then @vx, @vy = +1, 0
    end
  end

end
