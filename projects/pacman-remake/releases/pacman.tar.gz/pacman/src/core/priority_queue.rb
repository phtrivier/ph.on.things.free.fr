class PrioQueue

  def initialize
    clear
  end

  def clear
    @items = {}
    @lower_cost = nil
  end


  def put(item, cost)

    if (@items[cost] == nil)
      @items[cost] = []
    end

    if (@lower_cost == nil || cost < @lower_cost)
      @lower_cost = cost
    end

    @items[cost] << item

#    puts "Lower cost after putting #{item}, #{cost} : #{@lower_cost}"
  end

  def front
    res = @items[@lower_cost].delete_at(0)
    if (@items[@lower_cost].empty?)
      update_lower_cost!
    end
#    puts "Lower cost after returning #{res} : #{@lower_cost}"
    res
  end

  def update_lower_cost!
    @items.delete(@lower_cost)
    @lower_cost = @items.keys.min
  end

  def empty?
    @items.keys.empty?
  end

end
