require "life_cycle"

class RespawnStrategy
  def find_goal(scene, ghost)
    [10,9]
  end
end

class RespawnLifeCycle < LifeCycle

  SPAWN_TIME = 3000

  attr_reader :previous_life_cycle

  def initialize(ghost, previous_life_cycle, period=100000)
    super(previous_life_cycle.scene, ghost, period)
    @strategy = RespawnStrategy.new
    @planner = AStarPlanner.new(previous_life_cycle.scene)
    @previous_life_cycle = previous_life_cycle
    @goal_reached = false
    @goal_reached_time = 0
  end

  def update!(scene, dt)
    super(scene, dt)
    respawn_if_required
  end

  def respawn_if_required
    if (!@goal_reached and @ghost.on_goal?)
      @goal_reached = true
      @goal_reached_time = @last_update
    elsif (@goal_reached)
#      puts "Goal has been reached : last update is #{@last_update}, goal was reached at #{@goal_reached_time}"
      if (@last_update - @goal_reached_time > SPAWN_TIME)
#        puts "Asking for the ghost to respawn"
        @ghost.respawn!
      end
    end
  end

end
