class Node
  attr_reader :position, :parent, :cost, :heuristic

  def initialize(position, parent, cost=0, heuristic=0)
    @position = position
    @parent = parent
    @heuristic = heuristic
    @cost = cost
  end

  def make_path_helper(node, path)
#    puts "Calling helper for #{node} with path #{path}"
    path << node.position
    if (node.parent == nil)
      path
    else
      make_path_helper(node.parent, path)
    end
  end

  def make_path
    # puts "Making path for #{self}"
    make_path_helper(self, []).reverse!
  end

  def to_s
    "#{position.inspect}, [ #{parent} ]"
  end

  MAX_DEPTH = 5

  def is_ancestor?(position)

#    before = Time.new.to_f
    current_node = parent
    found = false
    finished = false
    depth = 0
    while (!found and !finished) #  and depth < MAX_DEPTH)
      if (current_node == nil)
        finished = true
      elsif (current_node.position == position)
        found = true
      else
        current_node = current_node.parent
      end
      depth = depth + 1
    end
#    now = Time.new.to_f
#    diff = now - before
#    puts "Checking whether point #{self} has #{position.inspect} in its ancestors; it tooked #{diff}"

    found
  end

end

class Searcher

  attr_accessor :agenda, :successor_builder, :start_position, :goal_position

  def is_goal?(node)
    node.position == @goal_position
  end

  def find_path

    @agenda.clear
    @agenda.add_node(@start_position, nil)
    found = false
    empty = false
    res = []
    while !found and !empty
      # puts "Checking agenda"
      # puts "Agenda state : #{agenda.inspect}"
      if (@agenda.empty?)
        empty = true
      else
        n = @agenda.front
 #       puts "Putting out node : #{n}"
        if (is_goal?(n))
  #        puts "Node is goal !"
          res = n.make_path
          found = true
        else
  #        puts "Node is not goal ..."
  #        puts "Asking for successors of #{n}"
          cp = n.cost
          succ = @successor_builder.successors(n, @goal_position)
          succ.each do |s|
            i,j,c,h = s
            # If the cost of the move is not given
            # we assume it is 1
            if (c == nil)
              c = 1
            end
            # If the estimated cost to the goal is not
            # given we assume to be 0 (it cannot overestimate)
            if (h == nil)
              h = 0
            end
            add_node([i,j],n,c, h)
          end
        end

      end

    end
    res
  end

  def add_node(s,n,c,h)
    if (!n.is_ancestor?(s))
      @agenda.add_node(s, n, c, h)
    end
  end

end
