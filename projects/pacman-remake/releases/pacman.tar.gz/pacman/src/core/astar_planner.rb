require "searcher"
require "astar_agenda"
require "maze_successor_builder"

class AStarPlanner

  def initialize(scene)
    @searcher = Searcher.new
    @searcher.agenda = AStarAgenda.new
    @searcher.successor_builder = MazeSuccessorBuilder.new(scene.maze)
  end

  def plan(maze, ghost, goal)
    gi,gj = ghost.pos
    i,j = maze.cell_coord_at_point(gi,gj)
    @searcher.start_position = [i,j]
    @searcher.goal_position = goal

    @searcher.find_path

  end

end
