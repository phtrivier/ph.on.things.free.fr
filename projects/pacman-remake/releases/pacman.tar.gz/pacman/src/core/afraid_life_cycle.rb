require "life_cycle"
require "astar_planner"

require "stupid_life_cycle"

class AfraidLifeCycle < LifeCycle

  def initialize(scene, ghost, period = 100000)
    super(scene)
    @strategy = StupidStrategy.new
    @planner = AStarPlanner.new(scene)
    @ghost = ghost
    @period = period
  end

end
