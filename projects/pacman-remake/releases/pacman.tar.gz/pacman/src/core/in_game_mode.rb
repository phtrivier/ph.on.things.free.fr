require "in_game_mode_base"
require "game_over_mode"
require "afraid_mode"

class InGameMode < InGameModeBase

  attr_accessor :super_pill_eaten

  def name
    :in_game
  end

  def initialize(scene)
    @scene = scene
    @start_time = 0
    @last_update_time = 0
    @super_pill_eaten = false
  end

  def getting_ready?
    @last_update_time - @start_time < 2000
  end

  def start!(time)
    @start_time = time
    @last_update_time = time
    @scene.enters_pac!
    @scene.enter_ghosts!
    @scene.start_ghosts!(time)
  end

  def next_game_mode
    res = self
    if (@super_pill_eaten)
      res = AfraidMode.new(@scene, self)
      res.start!(@last_update_time)
    elsif (@scene.maze.cleared?)
      res = InGameMode.new(@scene)
      @scene.maze.reload!
      res.start!(@last_update_time)
    else
      collisions = @scene.pac_collides?
      if (!collisions.empty?)
        @scene.one_life_down
        if (@scene.game_over?)
          res = GameOverMode.new(@scene)
          res.start!(@last_update_time)
        else
          res = InGameMode.new(@scene)
          res.start!(@last_update_time)
        end
      end
    end
    res
  end

  def draw(window)
    super(window)
    if (getting_ready?)
      window.draw_get_ready
    end
  end

end
