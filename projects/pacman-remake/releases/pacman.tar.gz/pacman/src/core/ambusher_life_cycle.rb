require "chaser_life_cycle"
require "astar_planner"

class AmbusherStrategy

  KNOWN_GOALS = [ [1,4], [1,15],
                  [4,4], [4,15],
                  [4,8], [4,11],
                  [6,8], [6,15],
                  [8,8], [8,11],
                  [10,4], [10,15],
                  [14,4], [14,15],
                  [16,6], [16,13],
                  [18,2], [18,17],
                  [20,8], [20,11]
                ]

  def initialize
    @index = 0
  end

  def man_dist(i,j,pos)
    a,b = pos
    di = a-i
    dj = b-j
    di.abs + dj.abs
  end

  def find_goal(scene, ghost)

    x,y = scene.pac.pos
    i0,j0 = scene.maze.cell_coord_at_point(x,y)
    # Minimum distance computed so far
    min_dist = -1

    KNOWN_GOALS.each_with_index do |goal, i|
      # Compute manahttan distance between the
      # intersection and the pacman
      # Put the closest one
      dist =  man_dist(i0,j0, goal)
      if (min_dist < 0 or dist < min_dist)
        min_dist = dist
        @index = i
      end
    end

    KNOWN_GOALS[@index]
  end

end

class AmbusherLifeCycle < LifeCycle

  def initialize(scene, ghost, period = ChaserLifeCycle::DEFAULT_PERIOD)
    super(scene, ghost, period)
    @strategy = AmbusherStrategy.new
    @planner = AStarPlanner.new(scene)
    @ghost = ghost
    @period = period
  end

end
