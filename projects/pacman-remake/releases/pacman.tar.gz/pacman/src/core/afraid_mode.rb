require "in_game_mode_base"

class AfraidMode < InGameModeBase

  def name
    :afraid
  end

  DEFAULT_LENGTH = 5000

  def initialize(scene, previous_mode)
    @scene = scene
    @previous_mode = previous_mode
    @length = DEFAULT_LENGTH
    @last_update_time = 0
  end

  def start!(time)
    @start_time = time
    @last_update_time = time
    @scene.force_afraid!(true)
  end

  def next_game_mode
    res = self
    if (@last_update_time - @start_time > @length)
      @scene.force_afraid!(false)
      res = @previous_mode
    elsif (@super_pill_eaten)
      # Handle the case where another super pill is eaten while one is active
      @start_time = @last_update_time
      @scene.force_afraid!(true)
      @super_pill_eaten = false
      res = self
    elsif (@scene.maze.cleared?)
      res = InGameMode.new(@scene)
      @scene.maze.reload!
      res.start!(@last_update_time)
    else
      collisions = @scene.pac_collides?
      if (!collisions.empty?)
        collisions.each do |g|
          @scene.kill_ghost!(g)
        end
      end
      res = self
    end
    res
  end

end
