class PauseMode

  attr_reader :previous_mode

  def name
    :pause
  end

  def initialize(previous_mode)
    @previous_mode = previous_mode
  end

  def start!(time)
  end

  def update!(dt)
  end

  def next_game_mode
    self
  end

  def draw(window)
     # Draw everything
    window.draw_cells
    window.draw_state_line("PAUSED")
  end

end
