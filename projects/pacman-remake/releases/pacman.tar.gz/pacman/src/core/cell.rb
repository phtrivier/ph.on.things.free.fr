class Cell

  NOTHING_EATEN = 0
  PILL_EATEN = 1
  SUPER_PILL_EATEN = 2

  attr_reader :super_pills_count, :pills_count

  def initialize(props = [:visible], p=0, sp=0)
    @walkable =  props.member?(:walkable)
    @pills_count = p
    @super_pills_count = sp
    @entry = props.member?(:entry)
    @visible = props.member?(:visible)
    @ghost_entry = props.member?(:ghost_entry)
  end

  def walkable?
    @walkable
  end

  def entry?
    @entry
  end

  def ghost_entry?
    @ghost_entry
  end

  def visible?
    @visible
  end

  def eat!
    res = NOTHING_EATEN
    if is_super_pill?
      @super_pills_count = 0
      res = SUPER_PILL_EATEN
    elsif is_pill?
      @pills_count = 0
      res = PILL_EATEN
    end
    res
  end

  def is_pill?
    @pills_count != 0
  end

  def is_super_pill?
    @super_pills_count != 0
  end
end
