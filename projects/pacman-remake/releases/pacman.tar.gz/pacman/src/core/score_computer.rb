# TODO(pht) Make it depend on the level, and
# add events to eat bonuses...
class ScoreComputer
  def pill_eaten(original_score)
    original_score + 10
  end

  def super_pill_eaten(original_score)
    original_score + 50
  end

  def ghost_killed(original_score)
    original_score + 200
  end
end
