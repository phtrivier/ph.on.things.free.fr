class LifeCycle

  attr_reader :scene
  attr_accessor :strategy, :planner, :period, :ghost

  def initialize(scene=nil, ghost=nil, period=nil)
    @scene = scene
    @ghost = ghost
    @period = period
  end

  def start!(time)
    @last_update = time
    @last_plan_time = nil
    @state = :starting
  end

  def update!(scene, dt)

    current_time = @last_update + dt

    if (should_plan_now?(current_time))
      plan!(scene)
      @last_plan_time = current_time
      @state = :acting
    else
      act!(scene, dt)
    end

    @last_update = current_time

  end

  def plan!(scene)
    goal = @strategy.find_goal(scene, @ghost)
    @ghost.goal = goal
    plan = @planner.plan(scene.maze, @ghost, goal)
    @ghost.plan = plan
  end

  def act!(scene, dt)
    scene.maze.try_move_ghost!(@ghost, dt)
  end

  def should_plan_now?(time)
    @state == :starting ||
      (@state == :acting and ((time - @last_plan_time) > @period))
  end

end
