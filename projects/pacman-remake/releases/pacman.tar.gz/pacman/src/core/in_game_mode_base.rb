class InGameModeBase

  def name
    nil
  end

  def getting_ready?
    false
  end

  def update!(dt)
    @last_update_time = @last_update_time + dt

    if (!getting_ready?)
      move_stuff_around!(dt)
    end

  end

  def move_stuff_around!(dt)
    @super_pill_eaten = false

    old_super_pills_count = @scene.maze.super_pills_count

    @scene.maze.try_move_pac!(@scene.pac, dt)
    @scene.ghosts.each do |g|
      g.update!(@scene, dt)
    end

    new_super_pills_count = @scene.maze.super_pills_count
    if (new_super_pills_count < old_super_pills_count)
      @super_pill_eaten = true
    end
  end

  def draw(window)
    # Draw everything
    window.draw_cells
    window.draw_pacman
    window.draw_ghosts
    window.draw_score
    window.draw_lives
  end

end
