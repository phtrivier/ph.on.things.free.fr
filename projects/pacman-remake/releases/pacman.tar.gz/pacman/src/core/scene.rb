require 'maze'
require 'pac'
require 'ghost'
require 'ghost_factory'
require "score_computer"
require "in_game_mode"
require "pause_mode"

class Scene

  DEFAULT_REMAINING_LIVES = 3

  attr_accessor :maze, :pac, :score_computer
  attr_reader :score, :ghosts, :remaining_lives
  attr_accessor :game_mode

  def initialize
    @ghosts = []
    @ghost_factory = GhostFactory.new
    @remaining_lives = DEFAULT_REMAINING_LIVES
  end

  def one_life_down
    @remaining_lives = @remaining_lives -1
  end

  def game_over?
    @remaining_lives == 0
  end

  # Puts the pac in the middle of the entry cell.
  def enters_pac!

    if (@maze.entry == nil)
      raise RuntimeError.new("You cannot make pac enter without an entry.")
    end

    @pac = Pac.new
    i,j = @maze.entry
    w = @maze.cell_w
    @pac.set_pos(w*j + w / 2, w*i + w / 2)
    @pac.set_vel(-1,0)
  end

  def start_score_computing!
    if (@score_computer == nil)
      raise RuntimeError.new("You cannot start the scene without a score computer.")
    end
    if (@maze == nil)
      raise RuntimeError.new("You cannot start the scene without a maze.")
    end
    @score = 0
    handler = lambda { |i,j,super_pill|
      if (super_pill)
        @score = @score_computer.super_pill_eaten(@score)
      else
        @score = @score_computer.pill_eaten(@score)
      end
    }
    @maze.add_pill_eaten_handler(handler)
  end

  def add_ghost!(g)
    @ghosts << g
  end

  # Start evolution of everyone in the maze
  def start!(time)
    @last_update_time = time
    @game_mode.start!(time)
  end

  def start_ghosts!(time)
    @ghosts.each do |g|
      g.start!(time)
    end
  end

  def update!(time)
    # Number of milliseconds since last update
    dt = time - @last_update_time

    @game_mode.update!(dt)

    @game_mode = @game_mode.next_game_mode

    @last_update_time = time
  end

  def enter_ghosts!
    @ghosts = []

    entries = @maze.ghost_entries

    entries.each_with_index do |entry, index|
      i,j = entry
      c = @maze.cell_center(i,j)
      x,y = c
      g = @ghost_factory.make_ghost(self, index, x, y)
      @ghosts << g
    end

  end

  def pac_collides?
    @ghosts.select do |g|
      !g.respawning? and @pac.collides_with?(g)
    end
  end

  def force_afraid!(afraid)
    ghosts.each do |g|
      g.set_afraid(afraid)
    end
  end


  def kill_ghost!(g)
    g.kill!
    @score = @score_computer.ghost_killed(@score)
  end

  # Loads a new maze from the path and set up everything
  def setup!(path)
    maze = Maze.new
    str = File.open(path).read
    maze.load!(str)
    @maze = maze
    @score_computer = ScoreComputer.new
    start_score_computing!
    @remaining_lives = DEFAULT_REMAINING_LIVES
  end

end
