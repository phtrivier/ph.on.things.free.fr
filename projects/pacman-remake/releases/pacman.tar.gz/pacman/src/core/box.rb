class Box
  attr_reader :x, :y, :w,:h

  def initialize(x,y,w, h)
    @x, @y = x, y
    @w, @h = w, h
  end

  def corners(x=@x, y=@y)
    hw = @w / 2.0
    hh = @h / 2.0
    [ [x - hw, y - hh],
      [x + hw, y - hh],
      [x + hw, y + hh],
      [x - hw, y + hh]  ]
  end

  def pos
    [@x, @y]
  end

  def dims
    [@w, @h]
  end

  def set_pos(x,y)
    @x = x
    @y = y
  end

  def boundaries
    { :top => @y,
      :bottom => @y + @h,
      :left => @x,
      :right => @x + @w
    }
  end

  def collides_with?(other)

    b1 = boundaries
    b2 = other.boundaries

    if (b1[:bottom] < b2[:top] )
      false
    elsif (b1[:top] > b2[:bottom])
      false
    elsif (b1[:right] < b2[:left])
      false
    elsif (b1[:left] > b2[:right])
      false
    else
      true
    end

  end

end
