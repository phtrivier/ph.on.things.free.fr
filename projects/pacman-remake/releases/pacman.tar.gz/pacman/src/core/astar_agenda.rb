require "priority_queue"

class AStarAgenda < PrioQueue
  def add_node(n,parent,c=1,h=0)
    parent_cost = 0
    if (parent != nil)
      parent_cost = parent.cost
    end
    cost_to_this = parent_cost + c
    priority = cost_to_this + h
    put(Node.new(n,parent, cost_to_this), priority)
  end
end
