require "cell"

class CellFactory

  def create_cell(letter)

    case letter
    when "#" then Cell.new()
    when "%" then Cell.new([])
    when "O" then Cell.new([:walkable, :visible], 0, 1)
    when "." then Cell.new([:walkable, :visible], 1, 0)
    when " " then Cell.new([:walkable, :visible])
    when "I" then Cell.new([:walkable, :visible, :entry])
    else
      if ("0" <= letter and letter <= "5")
        Cell.new([:walkable, :visible, :ghost_entry])
      else
        raise Exception.new("Invalid letter to parse : #{letter}")
      end
    end

  end

  def parse_line(line)
    res = []
    line.strip.each_byte do |b|
      c = b.chr
      res << create_cell(c)
    end
    res
  end


end
