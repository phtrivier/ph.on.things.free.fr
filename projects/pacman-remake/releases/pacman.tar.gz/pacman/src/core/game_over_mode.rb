class GameOverMode

  def initialize(scene)
    @scene = scene
  end

  def start!(time)
    @life = 0
  end

  def update!(dt)
    @life = @life + dt
  end

  def next_game_mode
    if (@life > 2000)
      TitleScreenMode.new(@scene)
    else
      self
    end
  end

  def name
    :game_over
  end

  def draw(window)
    window.draw_game_over
  end

end
