class TitleScreenMode

  def initialize(scene)
  end

  def start!(time)
  end

  def update!(time)
  end

  def next_game_mode
    self
  end

  def name
    :title
  end

  def draw(window)
    window.draw_title_screen
  end

end
