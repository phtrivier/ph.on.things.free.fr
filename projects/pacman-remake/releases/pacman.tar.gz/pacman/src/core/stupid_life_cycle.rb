require "life_cycle"
require "astar_planner"

class StupidStrategy

  def find_goal(scene, ghost)

    m = scene.maze
    h,w = m.dims

    found = false
    i,j = 0,0
    while (!found)
      i = rand(h)
      j = rand(w)
      if (m.valid_cell_position?(i,j) and
          m.cell(i,j).walkable?)
        found = true
      end
    end

    [i,j]
  end

end


class StupidLifeCycle < ChaserLifeCycle

  def initialize(scene, ghost, period = 5000)
    super(scene, ghost, period)
    @strategy = StupidStrategy.new
    @planner = AStarPlanner.new(scene)
  end

end
