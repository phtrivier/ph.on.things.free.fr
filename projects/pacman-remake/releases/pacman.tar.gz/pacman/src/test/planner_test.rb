require "test/unit"
require "mocha"

class PlannerTest < Test::Unit::TestCase

  def test_planner_finds_plan_with_predeterminned_algorithm


  end

end
