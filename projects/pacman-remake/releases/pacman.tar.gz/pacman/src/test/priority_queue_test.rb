require "test/unit"
require "priority_queue"

class PrioQueueTest < Test::Unit::TestCase

  def test_same_priority_is_a_queue

    p = PrioQueue.new

    assert p.empty?

    p.put("a", 0)
    p.put("b", 0)

    assert !p.empty?

    # Checking is destructive
    assert_equal "a", p.front
    assert_equal "b", p.front

    assert p.empty?

  end

  def test_cheapest_cost_at_front

    p = PrioQueue.new

    p.put("a", 5)
    p.put("b", 5)
    p.put("c", 3)
    p.put("d", 1)
    p.put("e", 2)

    # Checking is destructive
    assert_equal "d", p.front
    assert_equal "e", p.front
    assert_equal "c", p.front
    assert_equal "a", p.front
    assert_equal "b", p.front

    assert p.empty?

  end



end
