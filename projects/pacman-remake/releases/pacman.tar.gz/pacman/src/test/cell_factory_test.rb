require 'test/unit'
require "cell_factory"

class CellFactoryTest < Test::Unit::TestCase

  def test_creates_cell_from_letter

    f = CellFactory.new

    c = f.create_cell("#")
    assert !c.walkable?
    assert c.visible?
    assert_equal 0, c.pills_count
    assert_equal 0, c.super_pills_count
    assert !c.entry?

    c = f.create_cell("%")
    assert !c.walkable?
    assert !c.visible?
    assert_equal 0, c.pills_count
    assert_equal 0, c.super_pills_count
    assert !c.entry?

    c = f.create_cell("O")
    assert c.walkable?
    assert_equal 0, c.pills_count
    assert_equal 1, c.super_pills_count
    assert !c.entry?

    c = f.create_cell(".")
    assert c.walkable?
    assert_equal 1, c.pills_count
    assert_equal 0, c.super_pills_count
    assert !c.entry?

    c = f.create_cell("I")
    assert c.walkable?
    assert_equal 0, c.pills_count
    assert_equal 0, c.super_pills_count
    assert c.entry?

    c = f.create_cell(" ")
    assert c.walkable?
    assert_equal 0, c.pills_count
    assert_equal 0, c.super_pills_count
    assert !c.entry?

  end

  def test_parse_line
    f = CellFactory.new
    row = f.parse_line("#.O")
    c = row[0]
    assert !c.walkable?
    c = row[1]
    assert_equal 1, c.pills_count
    c = row[2]
    assert_equal 1, c.super_pills_count
  end

end
