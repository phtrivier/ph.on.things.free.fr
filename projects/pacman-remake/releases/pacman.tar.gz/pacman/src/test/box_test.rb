require 'test/unit'

require 'box'
class BoxTest < Test::Unit::TestCase

  def test_boxes_knows_its_corners
    b = Box.new(15.0, 15.0, 30.0, 30.0)
    corners = b.corners()
    assert_equal([0,0], corners[0])
    assert_equal([30,0], corners[1])
    assert_equal([30,30], corners[2])
    assert_equal([0,30], corners[3])
  end

  def test_boxes_knows_its_corners_at_any_position
    b = Box.new(15.0, 15.0, 30.0, 30.0)
    corners = b.corners(10.0, 20.0)
    # x <- x - 5, y <- y + 5
    assert_equal([-5,5], corners[0])
    assert_equal([25,5], corners[1])
    assert_equal([25,35], corners[2])
    assert_equal([-5,35], corners[3])
  end

  def test_boxes_known_whether_they_collapse

    b1 = Box.new(0,0, 10, 10)
    b2 = Box.new(0,0, 10, 10)

    assert b1.collides_with?(b2)
    assert b2.collides_with?(b1)

    b3 = Box.new(11, 11, 5, 5)
    assert !b1.collides_with?(b3)
    assert !b3.collides_with?(b1)

    b4 = Box.new(5, 5, 10, 10)
    assert b1.collides_with?(b4)
    assert b4.collides_with?(b1)


  end

end
