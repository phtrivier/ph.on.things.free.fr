require "test/unit"

require "afraid_mode"

class AfraidModeTest < Test::Unit::TestCase

  def test_afraid_mode_makes_ghost_afraid
    s = mock("scene")
    p = mock("previous_mode")
    a = AfraidMode.new(s,p)

    # Simplifying the :update! method
    # from the father ...
    class << a
      def update!(dt)
        @last_update_time = @last_update_time + dt
      end
    end

    @start = 231
    s.expects(:force_afraid!).with(false)
    s.expects(:force_afraid!).with(true)
    a.start!(@start)
    a.update!(@start + 6000)
    ngm = a.next_game_mode
    assert_equal p, ngm
  end

end
