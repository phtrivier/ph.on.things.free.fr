require "test/unit"
require "sprite"
require "mocha"

class SpriteTest < Test::Unit::TestCase

  def test_sprite_can_split_up_in_pairs
    s = Sprite.new(10,20)
    frames = [10, 20, 30]
    res = []
    s.pairs(frames) do |a,b,i|
      res << [a,b]
    end
    assert_equal [ [0,10], [10, 20], [20, 30]], res
  end

  def test_sprite_can_find_frame_corresponding_to_clock
    s = Sprite.new(10,20)
    frames = [10, 20, 30]
    assert_equal 0, s.frame_index_at(0, frames)
    assert_equal 0, s.frame_index_at(5, frames)
    assert_equal 1, s.frame_index_at(12, frames)
    assert_equal 1, s.frame_index_at(15, frames)
    assert_equal 2, s.frame_index_at(25, frames)
  end

  def test_knows_which_surface_to_show

    s = Sprite.new(20, 30)
    assert_equal 0, s.x
    assert_equal 0, s.y
    assert_equal 20, s.w
    assert_equal 30, s.h

    # A surface that would contain what has to be
    # in the surface
    sheet = mock("sprite_sheet")
    s.sprite_sheet = sheet

    # sprite should have 3 frame
    # One from 0 to 10
    # One from 10 to 20
    # One from 20 to 30
    # Than back to the first one
    s.frames = { :walk_up => [10, 20, 30] }
    s.animations = [:walk_up]
    s.animation = :walk_up

    # Initialy the first frame is given
    # surface, x, y, w, h  = s.current_frame
    assert_equal [sheet, 0,0,20,30], s.current_frame
    s.forward!(1) # count is now 1
    assert_equal [sheet, 0,0,20,30], s.current_frame

    # Then we move enough to be in the second frame.
    # Only x moves, for the moment, we don't handle frames
    # on anything else than a single line : this is enough.
    s.forward!(10) # count is now 11
    assert_equal [sheet, 20,0,20,30], s.current_frame
    s.forward!(1) # count is now 12
    assert_equal [sheet, 20,0,20,30], s.current_frame

    s.forward!(10) # count is now 22
    assert_equal [sheet, 40,0,20,30], s.current_frame

    s.forward!(10) # count should now be 2
    assert_equal [sheet, 0,0,20,30], s.current_frame

  end

  def test_sprite_uses_several_lines_for_several_animations
    s = Sprite.new(20, 30)
    sheet = mock("sprite_sheet")
    s.sprite_sheet = sheet

    s.animations = [:walk_up, :walk_down]
    s.frames = { :walk_up => [10, 20, 30],
      :walk_down => [10,20,30]
    }
    s.animation = :walk_up
    assert_equal [sheet, 0,0,20,30], s.current_frame
    s.animation = :walk_down
    assert_equal [sheet, 0,30,20,30], s.current_frame
  end

end
