require "test/unit"
require "in_game_mode"

class InGameModeTest < Test::Unit::TestCase

  def test_in_game_mode_checks_for_collisions
    @start = 2131

    s = stub("scene")

    s.expects(:enters_pac!).times(2)
    s.expects(:enter_ghosts!).times(2)
    s.expects(:start_ghosts!).with(@start).times(2)
    s.expects(:maze).returns(stub_everything("maze"))

    @i = InGameMode.new(s)

    @i.start!(@start)

    g = mock("ghost")
    s.expects(:pac_collides?).returns([g])
    s.expects(:one_life_down)
    s.expects(:game_over?).returns(false)

    ngm = @i.next_game_mode

    # TODO : Make it a 'prepare_state?'
    assert ngm != @i
    assert_equal :in_game, ngm.name

  end

  def test_in_game_mode_causes_game_over

    @start = 2131

    s = mock("scene")

    s.expects(:enters_pac!)
    s.expects(:enter_ghosts!)
    s.expects(:start_ghosts!).with(@start)
    s.expects(:maze).returns(stub_everything("maze"))

    @i = InGameMode.new(s)

    @i.start!(@start)

    g = mock("ghost")
    s.expects(:pac_collides?).returns([g])
    s.expects(:one_life_down)
    s.expects(:game_over?).returns(true)

    ngm = @i.next_game_mode

    assert ngm != @i
    assert_equal :game_over, ngm.name

  end

  def test_in_game_mode_turns_into_afraid_mode_when_super_pill_is_eaten

    @start = 2131

    s = mock("scene")

    s.expects(:enters_pac!)
    s.expects(:enter_ghosts!)
    s.expects(:start_ghosts!).with(@start)
    s.expects(:force_afraid!).with(true)

    @i = InGameMode.new(s)

    @i.start!(@start)

    @i.super_pill_eaten = true

    ngm = @i.next_game_mode
    assert_equal :afraid, ngm.name

  end


end
