require "mocha"

require "ghost"
require "life_cycle"

class LifeCycleTest < Test::Unit::TestCase

  def test_life_cycle_sense_plan_act

    l = LifeCycle.new
    # strategy
    s = mock()
    # planner
    p = mock()

    # Scene and ghost
    sc = mock()
    g = mock()
    m = mock()

    l.ghost = g
    l.strategy = s
    l.planner = p
    l.period = 5000

    @start = 1225

    l.start!(@start)

    # First update will cause a planning to be done
    s.expects(:find_goal).with(sc, g).returns([1,2])
    g.expects(:goal=).with([1,2])
    g.expects(:plan=).with([[1,1],[1,2]])
    sc.expects(:maze).returns(m)
    p.expects(:plan).with(m,g,[1,2]).returns([[1,1], [1,2]])
    l.update!(sc, 1000)

    # Second and third update will have a plan, so act is called in the end
    sc.expects(:maze).returns(m)
    m.expects(:try_move_ghost!).with(g,1000)
    l.update!(sc, 1000)

    sc.expects(:maze).returns(m)
    m.expects(:try_move_ghost!).with(g,1000)
    l.update!(sc, 1000)

    # We forget most of the other updates, but we ask for an update much later
    s.expects(:find_goal).with(sc, g).returns([1,2])
    g.expects(:goal=).with([1,2])
    g.expects(:plan=).with([[1,1],[1,2]])
    sc.expects(:maze).returns(m)
    p.expects(:plan).with(m,g,[1,2]).returns([[1,1], [1,2]])
    l.update!(sc, 6000)

  end


end
