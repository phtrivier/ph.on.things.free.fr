require "test/unit"

require "ghost"
require "mocha"

class GhostTest < Test::Unit::TestCase

  def test_ghost_has_a_goal
    # mock maze
    m = mock()
    @g = Ghost.new(m)
    @g.goal= [1,3]
    m.expects(:is_centered_on?).with(@g, 1,3).returns(false)
    assert !@g.on_goal?
    m.expects(:is_centered_on?).with(@g, 1,3).returns(true)
    assert @g.on_goal?
  end

  def test_properties
    m = mock()
    g = Ghost.new(m, 10, 20)
    assert_equal [10, 20], g.pos
  end

  def test_ghost_can_execute_a_part_of_a_plan
    m = mock()
    # size will be 30
    # ghost will start in 1,1
    @g = Ghost.new(m, 45, 45)
    @g.goal = [1,3]
    @g.plan= [ [1,2], [1,3], [2,3]]
    @g.velocity = 15.0

    # First test : i need to go right
    m.expects(:is_centered_on?).with(@g, 1,2).returns(false)
    m.expects(:cell_coord_at_point).with(45, 45).returns([1,1])
    assert_equal [0,0], @g.vel
    @g.act!(m)
    assert_equal [1,0], @g.vel

    @g.set_pos(45+30, 45)

    # Second test : I'm at the right position, but I keep going (this looks more natural)
    m.expects(:is_centered_on?).with(@g, 1,2).returns(true)
    @g.act!(m)
    assert_equal [1,0], @g.vel

    # Third test, now I need to go right
    m.expects(:is_centered_on?).with(@g, 1,3).returns(false)
    m.expects(:cell_coord_at_point).with(45+30, 45).returns([1,2])
    @g.act!(m)
    assert_equal [1,0], @g.vel

    @g.set_pos(45+30+30, 45)

    # That's it, wait
    m.expects(:is_centered_on?).with(@g, 1,3).returns(true)
    @g.act!(m)
    assert_equal [1,0], @g.vel

    # Now I need to go down
    m.expects(:is_centered_on?).with(@g, 2,3).returns(false)
    m.expects(:cell_coord_at_point).with(45+30+30, 45).returns([1,3])
    @g.act!(m)
    assert_equal [0,1], @g.vel

  end

  def test_ghosts_cycles_through_sense_plan_act_on_update
    s = mock()
    m = mock()
    g = Ghost.new(m, 45, 45)
    l = mock()
    g.life_cycle = l
    l.expects(:update!).with(s,1000)
    g.update!(s, 1000)
  end

  def test_killing_a_ghost_makes_it_respawn
    m = mock("maze")
    s = mock("scene", :maze => m)
    l = mock("life_cycle")
    l.expects(:scene).returns(s).times(2)
    g = Ghost.new(m, 45, 45)
    g.life_cycle = l
    g.regular_life_cycle = l
    assert !g.respawning?
    # Kill the ghost
    g.kill!
    assert g.respawning?
    assert_equal Ghost::RESPAWN_VELOCITY, g.velocity
    assert_equal RespawnLifeCycle, g.life_cycle.class
    assert_equal l, g.life_cycle.previous_life_cycle
    # Then respawn it
    g.respawn!
    assert !g.respawning?
    assert_equal Ghost::DEFAULT_VELOCITY, g.velocity
    assert_equal l, g.life_cycle
  end

end
