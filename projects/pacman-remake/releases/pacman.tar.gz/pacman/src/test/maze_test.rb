require 'test/unit'

require "maze"

class MazeTest < Test::Unit::TestCase

  def test_maze_is_loaded_from_file

    str =
<<EOF
######
#O0.I#
######
EOF

    m = Maze.new
    m.load!(str)

    assert_equal [[1,2]], m.ghost_entries

    assert !m.cell(0,0).walkable?
    assert m.cell(1,1).walkable?

    assert_equal 0, m.cell(0, 0).super_pills_count
    assert_equal 0, m.cell(0, 0).pills_count

    assert_equal 1, m.cell(1, 1).super_pills_count
    assert_equal 0, m.cell(1, 1).pills_count

    assert_equal 0, m.cell(1, 2).super_pills_count
    assert_equal 0, m.cell(1, 2).pills_count
    assert m.cell(1,2).ghost_entry?

    assert m.cell(1,4).entry?
    assert_equal [1,4], m.entry

    assert_equal 0, m.cell(1, 4).super_pills_count
    assert_equal 0, m.cell(1, 4).pills_count

    assert_equal 1, m.pills_count
    assert_equal 1, m.super_pills_count

    assert !m.cleared?

  end

  def test_points_can_be_located_on_cell
    str =
<<EOF
######
#O..I#
######
EOF

    m = Maze.new
    m.load!(str)

    assert_equal Maze::DEFAULT_CELL_W, m.cell_w
    w = m.cell_w

    assert_equal m.cell(0,0), m.cell_at_point(0,0)
    assert_equal m.cell(2,1), m.cell_at_point(w + 5, 2*w + 5)

  end

  def test_eating_pills_reduce_count

    str =
<<EOF
######
#O..I#
######
EOF
    m = Maze.new
    m.load!(str)

    assert_equal 1, m.super_pills_count
    m.eat!(1,1)
    assert_equal 0, m.super_pills_count

    assert_equal 2, m.pills_count
    m.eat!(1,2)
    assert_equal 1, m.pills_count
    m.eat_at_point!(3*m.cell_w + 5, m.cell_w)
    assert_equal 0, m.pills_count

    assert m.cleared?

  end

  def setup
    @m = Maze.new
    str = <<EOF
######
#O..I#
######
EOF
    @m.load!(str)
    @w = @m.cell_w
  end

  def test_maze_knows_whether_a_box_can_fit_at_a_position
    # A mock pacman (to give positions, etc..)
    b = mock()
    @m.cell_w = 30.0
    corners = [[33.0, 33.0], [55.0, 33.0], [56.0,58.0], [33.0, 58.0]]
    corners.each do |c|
      x,y = c
      assert(@m.cell_at_point(x,y).walkable?, "You should be able to walk on #{x},#{y}")
    end
    new_x,new_y = 44.0, 46.0
    b.expects(:corners).with(new_x, new_y).returns(corners)
    assert(@m.can_walk?(b,new_x, new_y))

    b = mock()
    corners = [[25, 25], [25, 45], [45,45], [25, 45]]
    new_x,new_y = 35.0, 35.0
    b.expects(:corners).with(new_x, new_y).returns(corners)
    assert(!@m.can_walk?(b,new_x, new_y))


    # Special case of the tunnels : some of the corners are nils,
    # but it should not bother too much
#     b = mock()
#     @m.cell_w = 30.0
#     corners = [[33.0, 33.0], [6*30.0 + 10, 33.0], [6*30.0 + 10,58.0], [33.0, 58.0]]
#     new_x,new_y = 44.0, 46.0
#     b.expects(:corners).with(new_x, new_y).returns(corners)
#     assert(@m.can_walk?(b,new_x, new_y))

  end

  def test_cell_coord_at_point
    w = @m.cell_w
    assert_equal [1,3], @m.cell_coord_at_point(3*w + w/2, 1*w + w/2)
  end

  def test_eating_events_are_propagated
    call = []
    @m.add_pill_eaten_handler(lambda { |i,j,super_pill|
                                call = [i,j,super_pill]
                              })

    w = @m.cell_w

    assert_not_nil @m.cell_at_point(3*w + w/2, 1*w + w/2)

    @m.eat_at_point!(3*w + w/2, 1*w + w/2)
    assert_equal [1,3,false], call

    @m.eat_at_point!(1*w + w/2, 1*w + w/2)
    assert_equal [1,1,true], call
  end

  def test_knows_if_a_box_is_centered_on_a_cell
    # mock box
    b = mock()
    # mock box is centered on cell [1,2]
    b.expects(:pos).returns([2*@w + @w/2, @w + @w/2]).times(2)
    assert @m.is_centered_on?(b, 1, 2, 10.0)
    assert !@m.is_centered_on?(b, 0, 2, 10.0)
    b.expects(:pos).returns([2*@w, @w])
    assert !@m.is_centered_on?(b, 1, 2, @w / 3)
  end

  def test_moving_pac_in_the_maze

    p = Pac.new
    # Initial position 1,2
    p.set_pos(@w + @w / 2.0, @w + @w / 2.0)
    p.velocity = 20
    p.set_vel +1.0, 0.0

    x,y = p.pos

    assert_equal [30, 30] , [x,y]
    assert @m.can_walk?(p, x, y)

    new_x = x + p.velocity
    new_y = y

    assert @m.can_walk?(p, new_x, new_y)

    @m.try_move_pac!(p, 1000)

    assert_equal([new_x, new_y], p.pos)

  end

  def test_knows_walkable_neighbours

    m = Maze.new()
    str = <<EOF
#####
#   #
#  ##
#####
EOF

    m.load!(str)
    assert !m.valid_cell_position?(-1,1)
    assert !m.valid_cell_position?(1,-1)
    assert !m.valid_cell_position?(1,5)
    assert !m.valid_cell_position?(4,1)


    ns = m.walkable_neighbours([1,1])
    assert_equal 2, ns.size
    assert ns.member?([1,2])
    assert ns.member?([2,1])

    ns = m.walkable_neighbours([1,2])
    assert_equal 3, ns.size
    assert ns.member?([1,1])
    assert ns.member?([1,3])
    assert ns.member?([2,2])

  end

#   def test_new_position_is_reverted_on_tunnels

#     m = Maze.new
#     w = Maze::DEFAULT_CELL_W
#     str= <<EOF
# ####
# %  %
# ####
# EOF
#     m.load!(str)
#     assert_equal w, m.cell_w

#     # From left side to right side
#     b = mock("box")
#     b.expects(:pos).returns([1, w + 10])
#     b.expects(:vel).returns([-1, 0])
#     b.expects(:velocity).returns(10)

#     x,y =  m.new_position(b, 1000)
#     assert_equal 4*w - 9, x
#     assert_equal w + 10, y

#     # From right side to left side
#     b = mock("box2")
#     b.expects(:pos).returns([4*w - 1, w + 10])
#     b.expects(:vel).returns([+1, 0])
#     b.expects(:velocity).returns(10)

#     x,y =  m.new_position(b, 1000)
#     assert_equal 9, x
#     assert_equal w + 10, y

#   end


end





