require "test/unit"
require "mocha"

require "searcher"
require "priority_queue"
require "astar_agenda"

class SearcherTest < Test::Unit::TestCase

  def test_build_path_from_node

    n = Node.new([0,0], nil)
    n1 = Node.new([0,1], n)
    n2 = Node.new([0,2], n1)

    assert_equal [[0,0], [0,1], [0,2]], n2.make_path

  end

  def test_node_is_in_path
    n = Node.new([0,0], nil)
    n1 = Node.new([1,1], n)
    n2 = Node.new([2,2], n1)

    assert !n.is_ancestor?([1,1])
    assert !n1.is_ancestor?([1,1])
    assert n2.is_ancestor?([1,1])

  end

  def test_searcher_find_path

    s = Searcher.new

    st = Node.new([0,0], nil)
    s.start_position = [0,0]

    a = mock("agenda")
    s.agenda = a

    b = mock()
    s.successor_builder = b

    s.goal_position = [1,1]

    assert !s.is_goal?(st)

    e = Node.new([1,1], st)
    assert s.is_goal?(e)

    a.expects(:clear)
    a.expects(:add_node).with([0,0], nil)
    a.expects(:empty?).returns(false).times(2)
    # Node is important !! You first want the node to
    # be returned to be the starting node, then the end
    # node. For some reason, it supposes that
    # you reverse everything ...
    a.expects(:front).returns(e)
    a.expects(:front).returns(st)
    b.expects(:successors).with(st, [1,1]).returns([[0,1], [1,1]], [1,1])
    a.expects(:add_node).with([0,1], st, 1, 0)
    a.expects(:add_node).with([1,1], st, 1, 0)

    assert_equal [[0,0], [1,1]], s.find_path

  end

  class StackAgenda < Array
    def front
      delete_at(0)
    end

    # c : cost from parent node to this new node
    # h : estimated code from this new node to the goal
    def add_node(n, parent, c = nil, h = nil)
      push Node.new(n,parent)
    end
  end

  class Maze1
    def successors(node, g)

      p = node.position
      case p
      when [0,0] then [[0,1]]
      when [0,1] then [[0,0], [0,2]]
      end
    end
  end

  class Maze
    def successors(node, g)

      p = node.position
      case p
      when [0,0] then [[0,1]]
      when [0,1] then [[0,0], [0,2]]
      when [0,2] then [[0,1], [0,3]]
      when [0,3] then [[0,2], [1,3]]
      when [1,1] then [[0,1], [2,1]]
      when [1,3] then [[0,3], [2,3]]
      when [2,1] then [[1,1], [2,2]]
      when [2,2] then [[2,1], [2,3]]
      when [2,3] then [[2,2], [1,3]]
        else raise RuntimeError.new("Invalid node : #{node.position.inspect}")
      end

    end
  end

  class CostMaze
    # It takes the same amount of time from everyone, but
    # we estimate the
    def uninformed_successors(node)

      p = node.position
      case p
      when [0,0] then [[0,1]]
      when [0,1] then [[0,0], [0,2], [1,1]]
      when [0,2] then [[0,1], [0,3]]
      when [0,3] then [[0,2], [1,3]]
      when [1,1] then [[0,1], [2,1]]
      when [1,3] then [[0,3], [2,3]]
      when [2,1] then [[1,1], [2,2]]
      when [2,2] then [[2,1], [2,3]]
      when [2,3] then [[2,2], [1,3]]
        else raise RuntimeError.new("Invalid node : #{node.position.inspect}")
      end

    end

    def successors(node, goal)

      i,j = goal
      succs = uninformed_successors(node)
      succs.collect do |succ|

        i0,j0 = succ

        di = i0 - i
        dj = j0 - j
        sq_dist = di*di + dj*dj
        h = Math.sqrt(sq_dist).floor

        [i0,j0,1, h]

      end

    end

  end


  def test_computes_estimation_right
    n = Node.new([0,0], nil)
    s = CostMaze.new
    assert_equal [[0,1,1,1]], s.successors(n, [0,2])

    n = Node.new([0,1], nil)
    assert_equal [[0,0,1,2],[0,2,1,2],[1,1,1,1]], s.successors(n, [2,2])

  end

  def test_search_in_small_maze
    s = Searcher.new
    s.agenda = StackAgenda.new
    s.successor_builder = Maze1.new

    s.start_position = [0,0]
    s.goal_position = [0,2]

    assert_equal [[0,0], [0,1], [0,2]], s.find_path
  end

  def test_search_in_real_maze
    s = Searcher.new
    s.agenda = StackAgenda.new
    s.successor_builder = Maze.new

    s.start_position = [0,0]
    s.goal_position = [2,2]

    p1 = [[0,0], [0,1], [0,2], [0,3], [1,3],[2,3],[2,2]]
    p2 = [[0,0], [0,1], [1,1], [2,1], [2,2]]

    p = s.find_path
    # This is the longest path that it finds !
    assert_equal p1, p
  end

  def test_astar_search_in_real_maze
    s = Searcher.new
    s.agenda = AStarAgenda.new
    s.successor_builder = CostMaze.new

    s.start_position = [0,0]
    s.goal_position = [2,2]

    p1 = [[0,0], [0,1], [0,2], [0,3], [1,3],[2,3],[2,2]]
    p2 = [[0,0], [0,1], [1,1], [2,1], [2,2]]

    p = s.find_path
    # This is the shortest path
    assert_equal p2, p
  end

end
