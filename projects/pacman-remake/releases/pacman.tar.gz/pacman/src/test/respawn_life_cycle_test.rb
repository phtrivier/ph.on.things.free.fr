require "test/unit"
require "respawn_life_cycle"
require "mocha"
class RespawnLifeCycleTest < Test::Unit::TestCase

  def test_life_cycle_respawns_when_goal_reached_for_long_enough

    g = mock("ghost")
    m = mock("maze")
    s = stub("scene", :maze => m)
    p = stub("previous_life_cycle", :scene => s)
    l = RespawnLifeCycle.new(g,p)

    l.start!(2314)

    g.expects(:on_goal?).returns(true)

    class << l
      def update!(scene, dt)
        @last_update = @last_update + dt
      end
    end

    l.respawn_if_required
    l.update!(mock("scene2"), RespawnLifeCycle::SPAWN_TIME + 1)
    g.expects(:respawn!)
    l.respawn_if_required

  end

end
