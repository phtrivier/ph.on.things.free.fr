require 'test/unit'

class PacTest < Test::Unit::TestCase

  def test_pac_changes_direction_when_steering
    @p = Pac.new
    assert_equal [0,0], @p.vel

    @p.steer(:left)
    assert_equal [-1, 0], @p.vel

    @p.steer(:right)
    assert_equal [+1, 0], @p.vel

    @p.steer(:up)
    assert_equal [0, -1], @p.vel

    @p.steer(:down)
    assert_equal [0, +1], @p.vel
  end

end
