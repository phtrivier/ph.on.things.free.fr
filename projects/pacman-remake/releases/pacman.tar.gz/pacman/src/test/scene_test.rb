require 'test/unit'
require 'mocha'

require 'scene'

class NonStartedInGameMode < InGameMode
  def start!(time)
    # Do nothing : the scene state is bootstrapped by hand
    # TODO Get rid of this by putting the moving code
    # where it belong
    @scene.start_ghosts!(time)
  end

  def getting_ready?
    false
  end

  def next_game_mode
    self
  end
end

class SceneTest < Test::Unit::TestCase

  def setup
    @m = mock("maze")
    @w = 30.0
    @init_x = 4*@w + @w/2
    @init_y = @w + @w/2

    @s = Scene.new
    @s.game_mode = NonStartedInGameMode.new(@s)

  end

  def test_scene_has_a_maze_and_a_pacman

    @s.maze = @m

    @m.expects(:cell_w).returns(@w).times(2)
    @m.expects(:entry).returns([1,4]).times(4)

    @s.enters_pac!
    assert_not_nil @s.pac
    assert_equal [@init_x, @init_y], @s.pac.pos
    assert_equal [-1,0], @s.pac.vel

    @s.enters_pac!
    assert_equal [@init_x, @init_y], @s.pac.pos
    assert_equal [-1,0], @s.pac.vel

  end

  # TODO : Add a test for the fact that no matter
  # the mode, the scene calls start and update on its game_mode

  # TODO : Move those tests to the in game mode test, actually

  def test_pac_moves_at_every_update
    @s.maze = @m

    @m.expects(:entry).returns([1,4]).times(2)
    @m.expects(:cell_w).returns(@w)

    @s.enters_pac!

    @m.expects(:try_move_pac!).with(@s.pac, 1000).times(2)
    @m.expects(:super_pills_count).returns(100).times(4)

    @start = 1213
    @s.start!(@start)

    @s.update!(@start + 1000)
    @s.update!(@start + 2000)
  end

  def test_ghosts_act_and_move_at_every_update

    @s.maze = @m

    @m.expects(:entry).returns([1,4]).times(2)
    @m.expects(:cell_w).returns(@w)

    @s.enters_pac!

    # A mock ghost
    g = mock()
    @s.add_ghost!(g)

    @m.expects(:try_move_pac!).with(@s.pac, 1000).times(2)
    @m.expects(:super_pills_count).returns(100).times(4)

    g.expects(:update!).with(@s, 1000).times(2)

    @start = 1213

    g.expects(:start!).with(@start)

    @s.start!(@start)

    @s.update!(@start + 1000)
    @s.update!(@start + 2000)

  end

  def test_ghosts_are_added_at_ghosts_entries

    @s.maze = @m

    assert @s.ghosts.empty?
    @m.expects(:ghost_entries).returns([[1,2]]).times(2)
    @m.expects(:cell_center).with(1,2).returns([10,20]).times(2)

    @s.enter_ghosts!

    assert !@s.ghosts.empty?
    g = @s.ghosts[0]

    assert_equal [10,20], g.pos

    # If called several times, the ghosts are recreated
    @s.enter_ghosts!
    assert_equal 1, @s.ghosts.size

  end


  def test_scene_increases_score_on_events
    # Score computer
    sc = mock("score_computer")
    @s.score_computer = sc
    m = Maze.new
    m.load!("I")
    @s.maze = m

    @s.start_score_computing!
    assert_equal 0, @s.score

    # Eaten cell
    c = mock("mock_cell")
    c.expects(:eat!).returns(Cell::PILL_EATEN)
    sc.expects(:pill_eaten).with(0).returns(100)
    m.eat_cell!(c, 1,2)

    assert_equal(100, @s.score)
  end

  def test_scene_knows_whether_things_collides
    @s.maze = @m
    p = mock("pac")
    @s.pac = p
    g1 = stub_everything("ghost1")
    g2 = stub_everything("ghost2")
    g3 = stub_everything("ghost3")
    @s.add_ghost!(g1)
    @s.add_ghost!(g2)
    @s.add_ghost!(g3)
    p.expects(:collides_with?).with(g1).returns(false)
    p.expects(:collides_with?).with(g2).returns(true)
    p.expects(:collides_with?).with(g3).returns(false)
    assert_equal [g2], @s.pac_collides?
  end

  def test_respawning_ghosts_do_not_count_in_collision
    @s.maze = @m
    p = mock("pac")
    @s.pac = p
    g1 = stub_everything("ghost1")
    g2 = stub_everything("ghost2")
    g3 = stub_everything("ghost3")
    @s.add_ghost!(g1)
    @s.add_ghost!(g2)
    @s.add_ghost!(g3)
    g2.expects(:respawning?).returns(true)
    p.expects(:collides_with?).with(g1).returns(false)
    p.expects(:collides_with?).with(g3).returns(false)
    # Respawning ghosts do not count
    assert_equal [], @s.pac_collides?
  end



  def test_scene_keeps_the_count_of_remaining_lifes
    assert_equal 3, @s.remaining_lives
    assert !@s.game_over?
    @s.one_life_down
    assert_equal 2, @s.remaining_lives
    assert !@s.game_over?
    @s.one_life_down
    @s.one_life_down
    assert_equal 0, @s.remaining_lives
    assert @s.game_over?
  end


end
