days = { }

File.open("commit-logs") do |file|

  file.each_line do |line|
#    m = line.match("(200\.)\-([0-9]^2)\-([0-9]^2)")
    m = line.match("(200\.-[0-9]{2}-[0-9]{2})\ ([0-9:]{8})")
    if (m!=nil)
#      puts m[1]
      if (!days[m[1]])
        days[m[1]] = []
      end
      days[m[1]] << m[2]
    end
  end

end

HOURS_PER_COMMIT = 1
hours = 0
days_count = days.keys.size
puts "Worked on #{days_count} different days."
days.keys.sort.each do |key|
  value = days[key]
  puts "Worked on #{key}, made #{value.size} commits."
  hours = hours + HOURS_PER_COMMIT * value.size
end

puts "Averaging at #{HOURS_PER_COMMIT} hours / commit, that would make #{hours} hours of work ; and an average of #{hours / days_count} hours/day. \nAlthough it sure doesn't mean anything"
